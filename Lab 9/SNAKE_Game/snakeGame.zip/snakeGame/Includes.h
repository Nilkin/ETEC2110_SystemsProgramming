#pragma once
#include <stdlib.h>			//standard library
#include <vector>			//vecotrs
#include <time.h>			//time for random
#include <SDL.h>			//SDL
#include <SDL_image.h>
#include <SDL_ttf.h>

#include <vector>
//SCREEN Dimensions
#define SCREEN_WIDTH 800
#define SCREEN_HEIGHT 600

using namespace std;